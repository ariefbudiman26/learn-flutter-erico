package com.example.appbar_customheight

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
