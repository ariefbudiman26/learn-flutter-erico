package com.example.hero_cliprrect

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
