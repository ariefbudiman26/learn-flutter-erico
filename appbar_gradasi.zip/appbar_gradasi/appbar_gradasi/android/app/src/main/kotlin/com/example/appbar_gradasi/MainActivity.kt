package com.example.appbar_gradasi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
