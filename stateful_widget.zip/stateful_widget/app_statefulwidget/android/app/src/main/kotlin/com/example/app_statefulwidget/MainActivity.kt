package com.example.app_statefulwidget

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
