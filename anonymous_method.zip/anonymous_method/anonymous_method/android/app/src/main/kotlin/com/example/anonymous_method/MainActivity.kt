package com.example.anonymous_method

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
