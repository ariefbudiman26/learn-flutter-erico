package com.example.multipagescreen_nav

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
