package com.example.clip_path

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
