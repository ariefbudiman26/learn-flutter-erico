package com.example.aplikasi_containerwidget

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
