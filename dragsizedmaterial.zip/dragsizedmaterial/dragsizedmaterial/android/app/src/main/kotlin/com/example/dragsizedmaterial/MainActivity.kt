package com.example.dragsizedmaterial

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
