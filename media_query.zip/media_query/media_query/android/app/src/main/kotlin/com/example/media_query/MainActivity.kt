package com.example.media_query

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
