package com.example.font_features

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
