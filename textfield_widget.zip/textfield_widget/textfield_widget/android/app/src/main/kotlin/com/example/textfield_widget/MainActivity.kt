package com.example.textfield_widget

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
