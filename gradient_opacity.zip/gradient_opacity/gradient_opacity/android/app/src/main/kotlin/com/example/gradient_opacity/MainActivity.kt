package com.example.gradient_opacity

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
