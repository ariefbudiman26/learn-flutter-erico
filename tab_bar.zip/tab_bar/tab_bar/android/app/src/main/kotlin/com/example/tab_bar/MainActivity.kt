package com.example.tab_bar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
