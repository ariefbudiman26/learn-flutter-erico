package com.example.button_belahketupat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
