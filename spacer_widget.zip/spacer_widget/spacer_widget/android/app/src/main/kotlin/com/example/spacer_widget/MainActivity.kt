package com.example.spacer_widget

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
