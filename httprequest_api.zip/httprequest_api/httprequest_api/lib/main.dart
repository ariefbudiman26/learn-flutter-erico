import 'package:flutter/material.dart';
import 'post_result_model.dart';
import 'user_model.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  PostResult? postResult = null;
  User? user = null;
  String output = "no data";
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text("API Demo"),
        ),
        body: Center(
            child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            // POST Method //
            // Text((postResult != null)
            //     ? postResult!.id +
            //         " | " +
            //         postResult!.name +
            //         " | " +
            //         postResult!.job +
            //         " | " +
            //         postResult!.created
            //     : "Tidak ada data"),

            // GET Method //
            // Text((user != null)
            //     ? user!.id + " | " + user!.name
            //     : "Tidak ada data"),

            // Kumpulan Data //
            Text(output),
            RaisedButton(
              onPressed: () {
                // POST Method //
                // PostResult.connectToAPI("Arief", "Programmer").then((value) {
                //   postResult = value;
                //   setState(() {});
                // });

                // GET Method //
                // User.connectToAPI("10").then((value) {
                //   user = value;
                //   setState(() {});
                // });

                // Kumpulan Data //
                User.getUsers("1").then((users) {
                  output = "";
                  for (int i = 0; i < users.length; i++)
                    output = output + "[ " + users[i].name + " ] ";
                  setState(() {});
                });
              },
              child:
                  // Text("POST"),
                  Text("GET"),
            )
          ],
        )),
      ),
    );
  }
}
