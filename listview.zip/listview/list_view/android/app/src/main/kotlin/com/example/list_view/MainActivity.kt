package com.example.list_view

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
