package com.example.animated_container

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
