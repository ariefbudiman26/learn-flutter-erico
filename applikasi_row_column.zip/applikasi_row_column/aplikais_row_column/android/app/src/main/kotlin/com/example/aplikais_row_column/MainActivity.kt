package com.example.aplikais_row_column

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
