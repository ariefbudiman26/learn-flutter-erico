package com.example.positioned_fab_loginpage

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
